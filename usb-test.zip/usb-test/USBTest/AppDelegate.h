/* AppDelegate */

#import <Cocoa/Cocoa.h>

#include <IOKit/IOKitLib.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <IOKit/hid/IOHIDLib.h>
#include <IOKit/hid/IOHIDKeys.h>

@interface AppDelegate : NSObject
{
}

- (void)findDevices;
- (int)ioIteratorCount:(io_iterator_t)ioIterator;
- (void)processDevice:(io_object_t)hidDevice;


@end
