#import "AppDelegate.h"

@implementation AppDelegate


- (id) init {
	if (!(self = [super init])) return nil;

	NSLog(@"init");

	[self findDevices];
	
	return self;

}


//- (IOHIDDeviceInterface **)openHidDeviceForUsagePage:(unsigned int)usagePage {

- (void)findDevices {

	SInt32 usbUsagePage = 0x01;

	NSMutableDictionary *matchDict = (NSMutableDictionary *)IOServiceMatching(kIOHIDDeviceKey);
//	[matchDict removeAllObjects];
	[matchDict setObject:[NSNumber numberWithUnsignedInt:usbUsagePage] forKey:[NSString stringWithUTF8String:kIOHIDDeviceUsagePageKey]];
	[matchDict setObject:[NSNumber numberWithUnsignedInt:0x06] forKey:[NSString stringWithUTF8String:kIOHIDDeviceUsageKey]];
	
	NSLog(@"matching dict %@", matchDict);

//	[matchDict retain]; // fixme: I believe this is required because IOServiceGetMatchingServices() consumes a reference, but need to make sure otherwise this leaks.
	
    // Search I/O registry for matching devices
	io_iterator_t hidObjectIterator = 0;
    IOReturn ioReturnValue = IOServiceGetMatchingServices(kIOMasterPortDefault, (CFMutableDictionaryRef)matchDict, &hidObjectIterator);
    BOOL noMatchingDevices = (ioReturnValue != kIOReturnSuccess) || (!hidObjectIterator);
    if (noMatchingDevices) {
		NSLog(@"No matching devices found, IO Return Value = %d", ioReturnValue);
		return;
	}

	int hidDeviceCount = [self ioIteratorCount:hidObjectIterator];
	if (!hidDeviceCount) {
		NSLog(@"Unable to find any matching HID devices");
		return;
	}
	NSLog(@"%d matching HID device(s) found", hidDeviceCount);

	io_object_t hidDevice;
	while (hidDevice = IOIteratorNext(hidObjectIterator)) {
		[self processDevice:hidDevice];
		IOObjectRelease(hidDevice);
	}

	IOObjectRelease(hidObjectIterator);
	
}


- (void)processDevice:(io_object_t)hidDevice {

	NSLog(@"hidDevice %d", hidDevice);

	IOCFPlugInInterface **plugInInterface = nil;
	SInt32 score = 0;
	IOReturn ioReturnValue = IOCreatePlugInInterfaceForService(hidDevice, kIOHIDDeviceUserClientTypeID, kIOCFPlugInInterfaceID, &plugInInterface, &score);
	if (ioReturnValue != kIOReturnSuccess) {
		NSLog(@"Unable to IOCreatePlugInInterfaceForService(): %d", ioReturnValue);
		return;
	}

	IOHIDDeviceInterface122 **hidDeviceInterface = nil;

	CFUUIDBytes uuid = CFUUIDGetUUIDBytes(kIOHIDDeviceInterfaceID);
	HRESULT plugInResult = (*plugInInterface)->QueryInterface(plugInInterface, uuid, (LPVOID)&hidDeviceInterface);
	(*plugInInterface)->Release(plugInInterface); // don't need this any longer
	if (plugInResult != S_OK) {
		NSLog(@"Unable to create device interface: %d", plugInResult);
		return;
	}

	ioReturnValue = (*hidDeviceInterface)->open(hidDeviceInterface, 0);
	if (ioReturnValue != kIOReturnSuccess) {
		NSLog(@"Unable to open device interface: %d", ioReturnValue);
		ioReturnValue = (*hidDeviceInterface)->Release(hidDeviceInterface);
		if (ioReturnValue) NSLog(@"Error releasing hidDeviceInterfaceVendorPage: %d", ioReturnValue);
		return;
	}
	
	

	NSArray *elements;
	NSMutableDictionary *matchDict = [NSMutableDictionary dictionary];
	[matchDict setObject:[NSNumber numberWithUnsignedInt:2] forKey:[NSString stringWithUTF8String:kIOHIDDeviceUsageKey]];
	[matchDict setObject:[NSNumber numberWithUnsignedInt:8] forKey:[NSString stringWithUTF8String:kIOHIDDeviceUsagePageKey]];
	ioReturnValue = (*hidDeviceInterface)->copyMatchingElements(
		hidDeviceInterface,
		(CFDictionaryRef)matchDict,
		(CFArrayRef *)&elements
	);

	unsigned int i, count = [elements count];
	IOHIDElementCookie cookie = NULL;
	for (i = 0; i < count; i++) {
		NSObject *obj = [elements objectAtIndex:i];
		if ([[obj valueForKey:@"UsagePage"] isEqualTo:[NSNumber numberWithInt:8]] && [[obj valueForKey:@"Usage"] isEqualTo:[NSNumber numberWithInt:2]]) {
//			NSLog(@"obj %@", obj);
			cookie = (IOHIDElementCookie)[[obj valueForKey:@"ElementCookie"] intValue];
			break;
		}
//		NSLog(@"usage page %@/%@", [obj valueForKey:@"UsagePage"], [obj valueForKey:@"Usage"]);
	}
	NSLog(@"cookie %d", cookie);


	IOHIDEventStruct valueEvent;
	bzero(&valueEvent, sizeof(valueEvent));
	valueEvent.value = 1;

	ioReturnValue = (*hidDeviceInterface)->setElementValue(
		hidDeviceInterface,
		cookie,
		&valueEvent,
		0, NULL, NULL, NULL	
	);
	if (ioReturnValue != kIOReturnSuccess) {
		NSLog(@"setelementvalue on failed");
		return;
	}
	
	sleep(1);
	
	valueEvent.value = 0;

	ioReturnValue = (*hidDeviceInterface)->setElementValue(
		hidDeviceInterface,
		cookie,
		&valueEvent,
		0, NULL, NULL, NULL	
	);
	if (ioReturnValue != kIOReturnSuccess) {
		NSLog(@"setelementvalue off failed");
		return;
	}
	


}












- (int)ioIteratorCount:(io_iterator_t)ioIterator {
	if (!ioIterator) return 0;
	int hidDeviceCount = 0;
	IOIteratorReset(ioIterator);
	while (IOIteratorNext(ioIterator)) hidDeviceCount++;
	IOIteratorReset(ioIterator);
	return hidDeviceCount;
}


@end
